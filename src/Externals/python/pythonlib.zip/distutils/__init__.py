"""distutils

The main package for the Python Module Distribution Utilities.  Normally
used from a setup script as

   from distutils.core import setup

   setup (...)
"""

__revision__ = "$Id: __init__.py 79147 2010-03-20 20:47:27Z benjamin.peterson $"

# Distutils version
#
# Updated automatically by the Python release process.
#
#--start constants--
__version__ = "3.1.2"
#--end constants--
